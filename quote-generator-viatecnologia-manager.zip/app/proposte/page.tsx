import type { Metadata } from "next"
import ProposalsDashboard from "@/components/proposals/proposals-dashboard"

export const metadata: Metadata = {
  title: "Proposte - ViaTecnologia",
  description: "Gestione delle proposte e preventivi",
}

export default function ProposalsPage() {
  return <ProposalsDashboard />
}

