import type { Metadata } from "next"
import AIToolsDashboard from "@/components/ai-tools/ai-tools-dashboard"

export const metadata: Metadata = {
  title: "AI Tools - ViaTecnologia",
  description: "Strumenti AI per ViaTecnologia",
}

export default function AIToolsPage() {
  return <AIToolsDashboard />
}

