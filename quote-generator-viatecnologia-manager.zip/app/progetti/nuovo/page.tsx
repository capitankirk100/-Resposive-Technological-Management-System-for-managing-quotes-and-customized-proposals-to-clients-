import type { Metadata } from "next"
import ProjectForm from "@/components/projects/project-form"

export const metadata: Metadata = {
  title: "Nuovo Progetto - ViaTecnologia",
  description: "Crea un nuovo progetto per ViaTecnologia",
}

export default function NewProjectPage() {
  return (
    <main className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-6">Nuovo Progetto</h1>
      <ProjectForm />
    </main>
  )
}

