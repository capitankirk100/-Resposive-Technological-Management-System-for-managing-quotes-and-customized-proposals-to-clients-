import type { Metadata } from "next"
import ProjectDetail from "@/components/projects/project-detail"

export const metadata: Metadata = {
  title: "Dettaglio Progetto - ViaTecnologia",
  description: "Visualizzazione dettagliata del progetto",
}

export default function ProjectDetailPage({ params }: { params: { id: string } }) {
  return <ProjectDetail id={params.id} />
}

