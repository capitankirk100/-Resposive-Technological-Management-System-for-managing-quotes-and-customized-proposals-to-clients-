import type { Metadata } from "next"
import ProjectsDashboard from "@/components/projects/projects-dashboard"

export const metadata: Metadata = {
  title: "Progetti - ViaTecnologia",
  description: "Gestione dei progetti",
}

export default function ProjectsPage() {
  return <ProjectsDashboard />
}

