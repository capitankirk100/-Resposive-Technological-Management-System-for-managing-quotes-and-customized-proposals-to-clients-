import type { Metadata } from "next"
import DashboardHomepage from "@/components/dashboard/dashboard-homepage"

export const metadata: Metadata = {
  title: "ViaTecnologia - Project Manager",
  description: "Sistema gestionale per ViaTecnologia",
}

export default function Home() {
  return <DashboardHomepage />
}

