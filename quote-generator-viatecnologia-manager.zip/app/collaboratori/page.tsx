import type { Metadata } from "next"
import CollaboratorsDashboard from "@/components/collaborators/collaborators-dashboard"

export const metadata: Metadata = {
  title: "Collaboratori - ViaTecnologia",
  description: "Gestione collaboratori per ViaTecnologia",
}

export default function CollaboratorsPage() {
  return <CollaboratorsDashboard />
}

