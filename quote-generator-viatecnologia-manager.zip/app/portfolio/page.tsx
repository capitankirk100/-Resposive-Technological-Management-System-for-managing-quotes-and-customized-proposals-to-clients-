import type { Metadata } from "next"
import PortfolioDashboard from "@/components/portfolio/portfolio-dashboard"

export const metadata: Metadata = {
  title: "Portfolio - ViaTecnologia",
  description: "Vetrina dei lavori creati con v0 per ViaTecnologia",
}

export default function PortfolioPage() {
  return <PortfolioDashboard />
}

