import type { Metadata } from "next"
import ClientsDashboard from "@/components/clients/clients-dashboard"

export const metadata: Metadata = {
  title: "Clienti - ViaTecnologia",
  description: "Gestione clienti per ViaTecnologia",
}

export default function ClientsPage() {
  return <ClientsDashboard />
}

