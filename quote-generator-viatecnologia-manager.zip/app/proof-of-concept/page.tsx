import type { Metadata } from "next"
import ProofOfConceptDashboard from "@/components/proof-of-concept/proof-of-concept-dashboard"

export const metadata: Metadata = {
  title: "Proof of Concept - ViaTecnologia",
  description: "Gestione dei proof of concept per ViaTecnologia",
}

export default function ProofOfConceptPage() {
  return <ProofOfConceptDashboard />
}

