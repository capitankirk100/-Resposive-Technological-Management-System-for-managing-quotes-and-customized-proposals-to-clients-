import type { Metadata } from "next"
import CodeManagerDashboard from "@/components/code-manager/code-manager-dashboard"

export const metadata: Metadata = {
  title: "Code Manager - ViaTecnologia",
  description: "Analisi e gestione del codice",
}

export default function CodeManagerPage() {
  return <CodeManagerDashboard />
}

